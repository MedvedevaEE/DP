﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Xml.Serialization;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        //public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\WindowsFormsApp1\библиотека.mdb";
        //private OleDbConnection myConnection;
        public Form2()
        {
            InitializeComponent();
            //myConnection = new OleDbConnection(connectString);
            //myConnection.Open();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Информационно-справочная система Библиотека позволяет осуществлять работу с базой данных, хранящей информацию о книгах." +
                "\n" + 
                "Для реализации какого-либо действия необходимо нажать кнопку, название которой совпадает с желаемым действием, располагающуюся на форме или выбрать соответствующий пункт главного меню." +
                "\n" +
                "Разработчик: Медведева Екатерина Евгеньевна", "О ПРОГРАММЕ");
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet.Книги". При необходимости она может быть перемещена или удалена.
            this.книгиTableAdapter.Fill(this.dataSet.Книги);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public class GridColumn
        {
            [XmlElement]
            public String Name { get; set; }

            [XmlElement]
            public String Index { get; set; }

            [XmlElement]
            public String Width { get; set; }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
