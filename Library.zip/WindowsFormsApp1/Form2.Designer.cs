﻿
namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataSet = new WindowsFormsApp1.DataSet();
            this.книгиTableAdapter = new WindowsFormsApp1.DataSetTableAdapters.КнигиTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.книгиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.инвентариальныйНомерDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iSBNББКDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОАвтораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.авторскийКодDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.описаниеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.разделDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.подразделDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоЭкземпляровDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЭкземпляраDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаВнесенияВФондDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.книгиBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1882, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(118, 24);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.инвентариальныйНомерDataGridViewTextBoxColumn,
            this.iSBNББКDataGridViewTextBoxColumn,
            this.фИОАвтораDataGridViewTextBoxColumn,
            this.авторскийКодDataGridViewTextBoxColumn,
            this.описаниеDataGridViewTextBoxColumn,
            this.разделDataGridViewTextBoxColumn,
            this.подразделDataGridViewTextBoxColumn,
            this.количествоЭкземпляровDataGridViewTextBoxColumn,
            this.ценаЭкземпляраDataGridViewTextBoxColumn,
            this.датаВнесенияВФондDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.книгиBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(44, 179);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1826, 318);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dataSet
            // 
            this.dataSet.DataSetName = "DataSet";
            this.dataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // книгиTableAdapter
            // 
            this.книгиTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(106, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(270, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Введите данные для поиска";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(461, 87);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(403, 34);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // книгиBindingSource
            // 
            this.книгиBindingSource.DataMember = "Книги";
            this.книгиBindingSource.DataSource = this.dataSet;
            // 
            // инвентариальныйНомерDataGridViewTextBoxColumn
            // 
            this.инвентариальныйНомерDataGridViewTextBoxColumn.DataPropertyName = "Инвентариальный номер";
            this.инвентариальныйНомерDataGridViewTextBoxColumn.HeaderText = "Инвентариальный номер";
            this.инвентариальныйНомерDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.инвентариальныйНомерDataGridViewTextBoxColumn.Name = "инвентариальныйНомерDataGridViewTextBoxColumn";
            this.инвентариальныйНомерDataGridViewTextBoxColumn.ReadOnly = true;
            this.инвентариальныйНомерDataGridViewTextBoxColumn.Width = 125;
            // 
            // iSBNББКDataGridViewTextBoxColumn
            // 
            this.iSBNББКDataGridViewTextBoxColumn.DataPropertyName = "ISBN/ББК";
            this.iSBNББКDataGridViewTextBoxColumn.HeaderText = "ISBN/ББК";
            this.iSBNББКDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iSBNББКDataGridViewTextBoxColumn.Name = "iSBNББКDataGridViewTextBoxColumn";
            this.iSBNББКDataGridViewTextBoxColumn.ReadOnly = true;
            this.iSBNББКDataGridViewTextBoxColumn.Width = 125;
            // 
            // фИОАвтораDataGridViewTextBoxColumn
            // 
            this.фИОАвтораDataGridViewTextBoxColumn.DataPropertyName = "ФИО автора";
            this.фИОАвтораDataGridViewTextBoxColumn.HeaderText = "ФИО автора";
            this.фИОАвтораDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.фИОАвтораDataGridViewTextBoxColumn.Name = "фИОАвтораDataGridViewTextBoxColumn";
            this.фИОАвтораDataGridViewTextBoxColumn.ReadOnly = true;
            this.фИОАвтораDataGridViewTextBoxColumn.Width = 125;
            // 
            // авторскийКодDataGridViewTextBoxColumn
            // 
            this.авторскийКодDataGridViewTextBoxColumn.DataPropertyName = "Авторский код";
            this.авторскийКодDataGridViewTextBoxColumn.HeaderText = "Авторский код";
            this.авторскийКодDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.авторскийКодDataGridViewTextBoxColumn.Name = "авторскийКодDataGridViewTextBoxColumn";
            this.авторскийКодDataGridViewTextBoxColumn.ReadOnly = true;
            this.авторскийКодDataGridViewTextBoxColumn.Width = 125;
            // 
            // описаниеDataGridViewTextBoxColumn
            // 
            this.описаниеDataGridViewTextBoxColumn.DataPropertyName = "Описание";
            this.описаниеDataGridViewTextBoxColumn.HeaderText = "Описание";
            this.описаниеDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.описаниеDataGridViewTextBoxColumn.Name = "описаниеDataGridViewTextBoxColumn";
            this.описаниеDataGridViewTextBoxColumn.ReadOnly = true;
            this.описаниеDataGridViewTextBoxColumn.Width = 125;
            // 
            // разделDataGridViewTextBoxColumn
            // 
            this.разделDataGridViewTextBoxColumn.DataPropertyName = "Раздел";
            this.разделDataGridViewTextBoxColumn.HeaderText = "Раздел";
            this.разделDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.разделDataGridViewTextBoxColumn.Name = "разделDataGridViewTextBoxColumn";
            this.разделDataGridViewTextBoxColumn.ReadOnly = true;
            this.разделDataGridViewTextBoxColumn.Width = 125;
            // 
            // подразделDataGridViewTextBoxColumn
            // 
            this.подразделDataGridViewTextBoxColumn.DataPropertyName = "Подраздел";
            this.подразделDataGridViewTextBoxColumn.HeaderText = "Подраздел";
            this.подразделDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.подразделDataGridViewTextBoxColumn.Name = "подразделDataGridViewTextBoxColumn";
            this.подразделDataGridViewTextBoxColumn.ReadOnly = true;
            this.подразделDataGridViewTextBoxColumn.Width = 125;
            // 
            // количествоЭкземпляровDataGridViewTextBoxColumn
            // 
            this.количествоЭкземпляровDataGridViewTextBoxColumn.DataPropertyName = "Количество экземпляров";
            this.количествоЭкземпляровDataGridViewTextBoxColumn.HeaderText = "Количество экземпляров";
            this.количествоЭкземпляровDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.количествоЭкземпляровDataGridViewTextBoxColumn.Name = "количествоЭкземпляровDataGridViewTextBoxColumn";
            this.количествоЭкземпляровDataGridViewTextBoxColumn.ReadOnly = true;
            this.количествоЭкземпляровDataGridViewTextBoxColumn.Width = 125;
            // 
            // ценаЭкземпляраDataGridViewTextBoxColumn
            // 
            this.ценаЭкземпляраDataGridViewTextBoxColumn.DataPropertyName = "Цена экземпляра";
            this.ценаЭкземпляраDataGridViewTextBoxColumn.HeaderText = "Цена экземпляра";
            this.ценаЭкземпляраDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ценаЭкземпляраDataGridViewTextBoxColumn.Name = "ценаЭкземпляраDataGridViewTextBoxColumn";
            this.ценаЭкземпляраDataGridViewTextBoxColumn.ReadOnly = true;
            this.ценаЭкземпляраDataGridViewTextBoxColumn.Width = 125;
            // 
            // датаВнесенияВФондDataGridViewTextBoxColumn
            // 
            this.датаВнесенияВФондDataGridViewTextBoxColumn.DataPropertyName = "Дата внесения в фонд";
            this.датаВнесенияВФондDataGridViewTextBoxColumn.HeaderText = "Дата внесения в фонд";
            this.датаВнесенияВФондDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.датаВнесенияВФондDataGridViewTextBoxColumn.Name = "датаВнесенияВФондDataGridViewTextBoxColumn";
            this.датаВнесенияВФондDataGridViewTextBoxColumn.ReadOnly = true;
            this.датаВнесенияВФондDataGridViewTextBoxColumn.Width = 125;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1882, 953);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Читателям";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.книгиBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSet dataSet;
        private DataSetTableAdapters.КнигиTableAdapter книгиTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn инвентариальныйНомерDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iSBNББКDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОАвтораDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn авторскийКодDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn описаниеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn разделDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn подразделDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоЭкземпляровDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЭкземпляраDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаВнесенияВФондDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource книгиBindingSource;
    }
}